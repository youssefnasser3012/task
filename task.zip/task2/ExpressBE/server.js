const express = require('express');
const cors = require('cors')


const app = express();


app.use(express.json());
app.use(cors())

app.post('/count', (req, res) => {
  try {
    const text = req.body.text ; 
    const letterCount = text.length;
    res.json({ letterCount }); 
  } catch (err) {
    console.error(err);
    res.status(500).send("Error receiving text"); 
  }
});


const PORT = 8080;
app.listen(PORT, () => {
  console.log(`Running on port ${PORT}`);
});
