import React, { useState } from 'react';
import { Card, Form } from 'react-bootstrap';
import axios from 'axios';

const Task = () => {
  const [text, setText] = useState('');
  const [receivedText, setReceivedText] = useState('');

  const handleCountLetters = async () => {
    try {
      const response = await axios.post("http://localhost:8080/count", {text});
      setReceivedText(response.data); // Set the received text in state
    } catch (error) {
      console.error('Error receiving text:');
    }
  };

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <Card style={{ width: '35rem', height: '35rem', borderRadius: '20px', backgroundColor: '#d1d1d1' }}>
        <Card.Body>
          <Card.Title style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '10vh', fontWeight: "bold", fontFamily: "cursive", fontSize: "1.5rem" }}>Container</Card.Title>
          <div style={{ marginLeft: "40px", fontSize: "1.2rem", marginBottom: "15px", marginTop: "30px" }}>
            <Form.Label htmlFor="inputPassword5">Paragraph :</Form.Label>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }} >
            <textarea placeholder="Enter your text here..." style={{ height: "18vh", width: "60vh", margin: "30px", borderRadius: "10px", border: "none", padding: "10px", resize: "none", fontSize: "16px" }} cols="30" rows="10" value={text} onChange={(e) => setText(e.target.value)}></textarea>
          </div>
          <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: "bold", fontFamily: "cursive", fontSize: "1.5rem", marginTop: "10px" }}>
            <button onClick={handleCountLetters} style={{ borderRadius: "8px", padding: "10px", backgroundColor: "#008080", border: "none", color: "#fff", cursor: "pointer" }}>Count Letters</button>
          </div>
          {receivedText && (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', fontWeight: "bold", fontFamily: "cursive", fontSize: "1.5rem", marginTop: "10px" }}>
              value: {receivedText.letterCount}
            </div>
          )}
        </Card.Body>
      </Card>
    </div>
  );
}

export default Task;
