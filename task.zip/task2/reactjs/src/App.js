import React from 'react'
import Task from "./Task";

function App() {
  return (
    <>
   <Task />
   </>
  );
}

export default App;
